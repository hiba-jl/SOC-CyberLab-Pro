"""Small, testable authentication-log detector for a defensive SOC lab.

Three detection rules, each mapped to MITRE ATT&CK:
- AUTH_BRUTE_FORCE            : many failed logins from one IP           (T1110.001)
- AUTH_PASSWORD_SPRAYING      : one IP failing on many different accounts (T1110.003)
- AUTH_SUCCESS_AFTER_FAILURES : a successful login right after failures   (T1110 / T1078)
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta
import ipaddress
import re
from pathlib import Path
from typing import Iterable

TIMESTAMP_FORMAT = "%Y-%m-%d %H:%M:%S"
LOG_PATTERN = re.compile(
    r"^(?P<timestamp>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) "
    r"(?P<event>LOGIN_FAILED|LOGIN_SUCCESS) src=(?P<ip>\S+) user=(?P<user>\S+)$"
)

# MITRE ATT&CK mapping for each rule: (tactic, technique id, technique name)
MITRE = {
    "AUTH_BRUTE_FORCE": ("Credential Access", "T1110.001", "Brute Force: Password Guessing"),
    "AUTH_PASSWORD_SPRAYING": ("Credential Access", "T1110.003", "Brute Force: Password Spraying"),
    "AUTH_SUCCESS_AFTER_FAILURES": ("Credential Access / Initial Access", "T1110, T1078",
                                    "Brute Force followed by Valid Accounts"),
}


@dataclass(frozen=True)
class DetectionConfig:
    window_minutes: int = 5
    alert_threshold: int = 3
    critical_threshold: int = 5
    spray_user_threshold: int = 3

    def validate(self) -> None:
        if self.window_minutes < 1:
            raise ValueError("window_minutes must be >= 1")
        if self.alert_threshold < 1:
            raise ValueError("alert_threshold must be >= 1")
        if self.critical_threshold < self.alert_threshold:
            raise ValueError("critical_threshold must be >= alert_threshold")
        if self.spray_user_threshold < 2:
            raise ValueError("spray_user_threshold must be >= 2")


@dataclass
class Alert:
    alert_id: str
    timestamp: str
    source_ip: str
    severity: str
    failed_attempts: int
    window_minutes: int
    rule_id: str
    title: str
    mitre_tactic: str
    mitre_technique_id: str
    mitre_technique: str
    evidence: list[str]
    recommended_action: str

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class AnalysisResult:
    alerts: list[Alert]
    invalid_lines: list[dict]
    total_lines: int
    valid_failed_events: int
    valid_success_events: int = 0


Event = tuple[datetime, str]  # (timestamp, username)


def parse_line(line: str) -> tuple[datetime, str, str, str] | None:
    """Return (timestamp, event, ip, user) or None if the format is not recognized."""
    match = LOG_PATTERN.match(line.strip())
    if not match:
        return None
    timestamp = datetime.strptime(match.group("timestamp"), TIMESTAMP_FORMAT)
    ip = str(ipaddress.IPv4Address(match.group("ip")))
    return timestamp, match.group("event"), ip, match.group("user")


def _make_alert(rule_id: str, title: str, ip: str, timestamp: datetime, severity: str,
                failed: int, config: DetectionConfig, evidence: list[str], action: str) -> Alert:
    tactic, technique_id, technique = MITRE[rule_id]
    prefix = {"AUTH_BRUTE_FORCE": "BF", "AUTH_PASSWORD_SPRAYING": "PS",
              "AUTH_SUCCESS_AFTER_FAILURES": "SAF"}[rule_id]
    return Alert(
        alert_id=f"{prefix}-{timestamp.strftime('%Y%m%d%H%M%S')}-{ip.replace('.', '-')}",
        timestamp=timestamp.strftime(TIMESTAMP_FORMAT),
        source_ip=ip,
        severity=severity,
        failed_attempts=failed,
        window_minutes=config.window_minutes,
        rule_id=rule_id,
        title=title,
        mitre_tactic=tactic,
        mitre_technique_id=technique_id,
        mitre_technique=technique,
        evidence=evidence,
        recommended_action=action,
    )


def _detect_brute_force(ip: str, failures: list[Event], config: DetectionConfig) -> Alert | None:
    """Highest number of failures from one IP inside the rolling window."""
    window = timedelta(minutes=config.window_minutes)
    best: tuple[int, datetime, list[Event]] | None = None
    left = 0
    for right, (timestamp, _user) in enumerate(failures):
        while timestamp - failures[left][0] > window:
            left += 1
        count = right - left + 1
        if count >= config.alert_threshold and (best is None or count > best[0]):
            best = (count, timestamp, failures[left:right + 1])
    if best is None:
        return None
    count, timestamp, events = best
    users = sorted({u for _, u in events})
    return _make_alert(
        "AUTH_BRUTE_FORCE", "Repeated failed authentication attempts", ip, timestamp,
        "CRITICAL" if count >= config.critical_threshold else "ALERT", count, config,
        [f"{count} failed login events in {config.window_minutes} minutes",
         f"Observed username(s): {', '.join(users)}"],
        "Validate whether activity is expected; review surrounding logs; if unauthorized, "
        "follow the approved account/IP containment process.",
    )


def _detect_password_spraying(ip: str, failures: list[Event], config: DetectionConfig) -> Alert | None:
    """One IP failing on many *different* accounts inside the rolling window."""
    window = timedelta(minutes=config.window_minutes)
    best: tuple[int, datetime, list[Event]] | None = None
    left = 0
    for right, (timestamp, _user) in enumerate(failures):
        while timestamp - failures[left][0] > window:
            left += 1
        distinct = len({u for _, u in failures[left:right + 1]})
        if distinct >= config.spray_user_threshold and (best is None or distinct > best[0]):
            best = (distinct, timestamp, failures[left:right + 1])
    if best is None:
        return None
    distinct, timestamp, events = best
    users = sorted({u for _, u in events})
    return _make_alert(
        "AUTH_PASSWORD_SPRAYING", "Password spraying: one source, many accounts", ip, timestamp,
        "CRITICAL" if distinct >= config.critical_threshold else "ALERT", len(events), config,
        [f"{distinct} different accounts targeted in {config.window_minutes} minutes",
         f"Targeted account(s): {', '.join(users)}"],
        "Check whether any targeted account later logged in successfully; consider blocking the "
        "source IP and enforcing MFA / lockout policy on the targeted accounts.",
    )


def _detect_success_after_failures(ip: str, failures: list[Event], successes: list[Event],
                                   config: DetectionConfig) -> list[Alert]:
    """A successful login preceded by enough failures from the same IP: possible compromise."""
    window = timedelta(minutes=config.window_minutes)
    alerts: list[Alert] = []
    for success_time, success_user in successes:
        recent = [(t, u) for t, u in failures if success_time - window <= t <= success_time]
        if len(recent) < config.alert_threshold:
            continue
        users = sorted({u for _, u in recent})
        alerts.append(_make_alert(
            "AUTH_SUCCESS_AFTER_FAILURES", "Successful login after repeated failures", ip,
            success_time, "CRITICAL", len(recent), config,
            [f"{len(recent)} failed login events in the {config.window_minutes} minutes before success",
             f"Successful account: {success_user}",
             f"Failed username(s): {', '.join(users)}"],
            "Treat as a possible account compromise: verify with the account owner, reset the "
            "password, review the session activity and contain the source IP.",
        ))
    return alerts


def analyze_lines(lines: Iterable[str], config: DetectionConfig | None = None) -> AnalysisResult:
    config = config or DetectionConfig()
    config.validate()
    failures: dict[str, list[Event]] = defaultdict(list)
    successes: dict[str, list[Event]] = defaultdict(list)
    invalid_lines: list[dict] = []
    total = valid_failed = valid_success = 0

    for line_no, raw in enumerate(lines, start=1):
        total += 1
        line = raw.strip()
        if not line:
            continue
        try:
            parsed = parse_line(line)
            if parsed is None:
                raise ValueError("Unrecognized log format")
            timestamp, event, ip, username = parsed
            if event == "LOGIN_FAILED":
                failures[ip].append((timestamp, username))
                valid_failed += 1
            else:
                successes[ip].append((timestamp, username))
                valid_success += 1
        except (ValueError, OverflowError) as exc:
            invalid_lines.append({"line": line_no, "raw": line, "reason": str(exc)})

    alerts: list[Alert] = []
    for ip in sorted(set(failures) | set(successes)):
        ip_failures = sorted(failures.get(ip, []))
        ip_successes = sorted(successes.get(ip, []))
        if ip_failures:
            for detected in (_detect_brute_force(ip, ip_failures, config),
                             _detect_password_spraying(ip, ip_failures, config)):
                if detected:
                    alerts.append(detected)
            alerts.extend(_detect_success_after_failures(ip, ip_failures, ip_successes, config))
    alerts.sort(key=lambda a: (a.timestamp, a.source_ip, a.rule_id))
    return AnalysisResult(alerts, invalid_lines, total, valid_failed, valid_success)


def analyze_file(path: str | Path, config: DetectionConfig | None = None) -> AnalysisResult:
    with open(path, "r", encoding="utf-8-sig", errors="replace") as handle:
        return analyze_lines(handle, config)
