from soc_pro.detector import DetectionConfig, analyze_lines

def line(minute, ip="192.168.1.40", user="alice"):
    return f"2026-10-14 12:{minute:02d}:00 LOGIN_FAILED src={ip} user={user}"

def test_below_threshold_does_not_alert():
    result = analyze_lines([line(0), line(1)], DetectionConfig())
    assert result.alerts == []

def test_alert_threshold():
    result = analyze_lines([line(0), line(1), line(2)], DetectionConfig())
    assert len(result.alerts) == 1
    assert result.alerts[0].severity == "ALERT"
    assert result.alerts[0].failed_attempts == 3

def test_critical_threshold():
    result = analyze_lines([line(0), line(1), line(2), line(3), line(4)], DetectionConfig())
    assert len(result.alerts) == 1
    assert result.alerts[0].severity == "CRITICAL"
    assert result.alerts[0].failed_attempts == 5

def test_window_expires_old_events():
    lines = [line(0), line(1), line(2), line(10)]
    result = analyze_lines(lines, DetectionConfig(window_minutes=5, alert_threshold=3, critical_threshold=5))
    assert len(result.alerts) == 1
    assert result.alerts[0].failed_attempts == 3

def test_invalid_ip_is_reported():
    result = analyze_lines(["2026-10-14 12:00:00 LOGIN_FAILED src=999.1.1.1 user=alice"])
    assert len(result.invalid_lines) == 1
    assert result.alerts == []

def test_unrecognized_line_is_reported():
    result = analyze_lines(["this is not a supported log"])
    assert len(result.invalid_lines) == 1

def test_separate_ips_are_not_combined():
    result = analyze_lines([line(0), line(1), line(2, ip="192.168.1.41")])
    assert result.alerts == []


# --- Password spraying (T1110.003) -----------------------------------------

def test_password_spraying_detected():
    lines = [line(0, user="alice"), line(1, user="bob"), line(2, user="carol")]
    result = analyze_lines(lines, DetectionConfig())
    spray = [a for a in result.alerts if a.rule_id == "AUTH_PASSWORD_SPRAYING"]
    assert len(spray) == 1
    assert spray[0].mitre_technique_id == "T1110.003"
    assert "3 different accounts" in spray[0].evidence[0]


def test_same_user_failures_are_not_spraying():
    lines = [line(0), line(1), line(2), line(3)]
    result = analyze_lines(lines, DetectionConfig())
    assert all(a.rule_id != "AUTH_PASSWORD_SPRAYING" for a in result.alerts)


def test_spraying_outside_window_is_ignored():
    lines = [line(0, user="alice"), line(1, user="bob"), line(10, user="carol")]
    result = analyze_lines(lines, DetectionConfig(window_minutes=5))
    assert all(a.rule_id != "AUTH_PASSWORD_SPRAYING" for a in result.alerts)


# --- Success after failures (T1110 / T1078) ---------------------------------

def success(minute, ip="192.168.1.40", user="alice"):
    return f"2026-10-14 12:{minute:02d}:00 LOGIN_SUCCESS src={ip} user={user}"


def test_success_after_failures_is_critical():
    lines = [line(0), line(1), line(2), success(3)]
    result = analyze_lines(lines, DetectionConfig())
    saf = [a for a in result.alerts if a.rule_id == "AUTH_SUCCESS_AFTER_FAILURES"]
    assert len(saf) == 1
    assert saf[0].severity == "CRITICAL"
    assert saf[0].mitre_technique_id == "T1110, T1078"
    assert result.valid_success_events == 1


def test_normal_success_does_not_alert():
    result = analyze_lines([success(0)], DetectionConfig())
    assert result.alerts == []


def test_success_long_after_failures_is_ignored():
    lines = [line(0), line(1), line(2), success(30)]
    result = analyze_lines(lines, DetectionConfig(window_minutes=5))
    assert all(a.rule_id != "AUTH_SUCCESS_AFTER_FAILURES" for a in result.alerts)


# --- MITRE mapping -----------------------------------------------------------

def test_every_alert_has_mitre_mapping():
    lines = [line(0, user="alice"), line(1, user="bob"), line(2, user="carol"), success(3)]
    result = analyze_lines(lines, DetectionConfig())
    assert result.alerts
    for alert in result.alerts:
        assert alert.mitre_technique_id.startswith("T1")
        assert alert.mitre_tactic
